# SPDM TEST enviroments

## Docker

### socket: Permission denied(non-root user)
```bash
$ sudo chmod 666 /var/run/docker.sock
```

### Docker build & run
```bash
$ docker build -t spdm_test:v1 .
$ docker run -d spdm_test:v1
```

### Access the inside of a Docker container
```bash
$ docker exec -it <CONTAINER ID or NAMES> /bin/bash
```

### Delete docker container & image
```bash
$ docker rm -f $(docker ps -aq)
$ docker rmi -f $(docker images -q)
```

## SPDM test command in container

- sample 인증서 위치  
`libspdm/unit_test/sample_key/`

- test용 인증서 새로 생성
```bash
$ auto_gen_cert.sh
```

- emulation 명령어
```bash
$ spdm_device_attester_sample
$ spdm_device_validator_sample
$ spdm_responder_emu # listen localhost port 2323
$ spdm_requester_emu # send localhost port 2323
$ spdm_dump
```

## VScode extention for Debugging
We need `Dev Containers` & `Remote Development`

디버깅을 위해 Dev Containers를 이용하여 container 환경에 접속한다.
- VSCode에서 명령 팔레트(Ctrl+Shift+P)를 열고
    - Dev Containers: Reopen in Container  
    or 
    - Dev Containers: Attach to Running Container(container내부에서 cpp debug를 위한 vscode extension 설치 필요)

기존 VScode에서 디버깅하는 것과 동일하게 디버깅
1. Ctrl+Shift+P를 눌러 명령 팔레트를 연다
2. launch.json에 정의된 디버깅 설정 목록이 표시
3. 원하는 디버깅 설정 선택


### Reference
https://github.com/DMTF/libspdm  
https://github.com/DMTF/spdm-emu  
https://github.com/DMTF/spdm-dump